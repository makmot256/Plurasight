package hello
// default values  allow the primary constructor to be called without explicitly providing values for length and width.
class Rectangle(var width: Int = 0,var length: Int = 0) {

    constructor(width: Int) : this(length = 10) {// Delegates to the primary constructor with default values
        this.width = width
    }
}

    fun main(){
        val r = Rectangle(2,5)
        val r2 = Rectangle(78)
        println("width:${r.width} length:${r.length}")
        println(r2.width)
        println(r2.length)
    }


