package hello

fun main(){
    val str: String = "4a"
    var num : Int = try {
        str.toInt()
    }
    catch(e : NumberFormatException){
        -1
    }
    num++
    println(num)
 /*   or
    try{
        num = str.toInt()
    }
    catch(e : NumberFormatException){
        println(e)
    }

  */
}
