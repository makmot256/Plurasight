//@file:JvmName("First1") specifies the name of the Java class generated from the kotlin file
package hello
import java.util.*

fun myFunction(){
    println("i got executed")
}
fun myFun(name:String){
    println(name)
}
fun myFunction2(x:Int):Int{
    return x + 5
}
@JvmOverloads
fun myFunction4(x:Int = 6):Int{// default parameters
    return x + 5
}
//Shorter Syntax for Return Values
fun myFunction3(x:Int, y:Int) = x + y
fun myFunction5(x:Int, y:Double) = x + y

fun main(){
    var p : String
    p ="kiso"
    var `in`  ="APK" // use of a backtick inorder to use the in keyword as a variable name
    println(`in`)

    var r : Float = 4.5f

    println("Hello World")
    println(3+3)
    var age = 23
    age++
    println(age)
    val name = "Arnold"
    println(name)
    var number: Int
    number = 23
    var isKotlinFun: Boolean = true
    var isFishTasty = false
    println(isFishTasty)
    println(isKotlinFun)
    var surname:String = "Kisomose"
    println(surname[0])// accessing a character of a string
    println(surname[5])
    println(surname.length)
    println(23 + number)
    var letter = 'A'
    println(letter)
    val x :Int = 3
    val y : Double = x.toDouble()// Type conversion
    val tex : String = x.toString()
    println(y)
    println(tex)
    //String functions
    println(surname.uppercase())
    println(surname.lowercase())

    //null handling
    var t :String? = null
    println(t)

    //comparring strings
    var txt1 = "hello"
    var txt2 = "hello"
    println(txt1.compareTo(txt2))
    //concatentation
    println("$txt1 $txt2")//string templates
    println(txt1+" "+txt2)
    println(txt1.plus(txt2))

    //Finding a String in a String
    var txt = "Please locate where 'locate' occurs!"
    println(txt.indexOf("locate"))  // Outputs 7. Kotlin counts positions from zero


    if(18<20){
        println("Good")
    }
    //you can also use if..else statements as expressions (assign a value to a variable and return it)
    val time = 20
    val greeting = if(time < 18) {
        "Good day"
    }
    else {
        "Good evening"
    }
    println(greeting)
    //Kotlin when
    val day = 4
    val result = when(day){
        1->"Monday"
        2->"Tuesday"
        3->"Wednesday"
        4 -> "Thursday"
        5 -> "Friday"
        6 -> "Saturday"
        7 -> "Sunday"
        else->"Invalid day"
    }
    println(result)

    //loops
    var  i =0
    while(i<5){
        println(i)
        i++
    }
    var k = 1
    do{
        print(k)
        print(" ")
        k++
    }
    while(k<5)
    println()

    //arrays
    val cars = arrayOf("Volvo","BMW","Ford","Mazda")
    println(cars[3])
    cars[1]= "opel"
    // or cars.set(1,"Opel")
    println(cars[1])
    //or
    println(cars.get(1))
    println(cars.size)
    //check if an lement exists
    if("Volvo" in cars) {
        println("It exists")
    }
    else{
        println("It does not exist")
    }
    var n = IntArray(4)
    n.set(0,1)

    var n1 = DoubleArray(4)
    n1.set(0,1.18)

    var n2 = arrayOfNulls<String>(4)
    n2.set(0,"APK")

    //loop through an array
    for(x in cars){
        println(x)
    }
    //Ranges
    for(x in 5..15){
       print(x)
       print(" ")
    }
    println()
    for(char in 'a'..'x'){
        print(char)
    }
    for (nums in 5..15) {
        if (nums == 10) {
            break
        }
        println(nums)
    }
    for (nums in 5..15) {
        if (nums == 10) {
            continue
        }
        println(nums)
    }
    var nums = 100..120
    for(x in nums step 2){//step 2 increments by 2
        print("$x ")
    }
    println()
    for(x in 16 downTo 10){// downTo for descending order or 16.downTo(10)
        print("$x ")
    }
    println()
    var num = 10..16
    for(x in num.reversed()){// downTo for descending order or 16.downTo(10)
        print("$x ")
    }
    println()
    for(x in 1 until 16){// 16 is not included
        print("$x ")
    }
    println()

    //functions
    myFunction()//  call a function
    myFun("Kisomose")
    println(myFunction2(5))
    println(myFunction3(5, 15))
    println(myFunction4())
    println(myFunction5(y = 23.1, x= 2))// for named parameters order doesnt matter

    //string comparison
    var text = "Arnold"
    var text2 = "parnold"
    println(text.equals(text2))
    //or
    println(text == text2)
    //list and map
     var even = listOf(2,4,6,8,10,12) //arraylist
    println(even[3])
    for((i,e) in even.withIndex()){
        println("$i : $e")
    }
    println(even.indexOf(12))
    //even.add(14) causes an error because the list is immutable( read only)

    var person = TreeMap<String,Int>()
    person["Arnold"] = 21
    person["Peter"] = 22

    for((name,age) in person){
        println("$name : $age")
    }

    var son = Person()
    son.name = "Peter"
    son.age = 43
    son.show()

    //mutable lists
    var odd = mutableListOf<Int>(1,3,5,7)
    odd.add(11)
    for(x in odd){
        print("$x ")
    }
    println()
    odd.forEach({println(it)})
   //or  odd.forEach{println(it)}

    //list of objects
    var per = listOf<Person5>(Person5(12,"Peter"),Person5(14,"Bob"),
        Person5(16,"Alex"))
    for(p in per){
        println(p)
    }
    val doubled: List<Int> = odd.map{ it * 2 } // most preferred
   //or  val doubled: List<Int> = odd.map({ it * 2 })
    for(d in doubled){
        println(d)
    }

    var numbers = listOf<Int>(1,2,3,4,5,6,7,8,9)
    val evens = numbers.filter { it%2==0 }
    evens.forEach {print("$it ") }
    println()
    val doubles = evens.map{it * 2}
    doubles.forEach{print("$it ")}
    println()
    //or do it at once

    var results = numbers.filter { it%2==0 }.map{it * 2}
    results.forEach{print("$it ")}

}
//Function Extension
fun Person.show(){
    println(this.age)
    println(this.name)
}
