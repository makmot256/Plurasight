package hello
//Data class helps us achieve cloning, toString(), equals()
data class Book(var price :Int, var title : String)

fun main(){
    val book = Book(20000,"Kotlin")
    println(book)
    val b = book.copy()// cloning
    println(b == book)
    book.price = 15000
    println(b.equals(book))
    val b2 = book.copy(50000,"OOP")
    println(b2)
}