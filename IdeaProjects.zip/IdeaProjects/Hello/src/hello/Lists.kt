package hello

fun get_result(numbers:List<Int>):List<Int>{
    val nums1 = mutableSetOf<Int>()
    val nums2 = mutableSetOf<Int>()
    for(number in numbers){
        if(!nums1.add(number)){
            nums2.add(number)
        }
    }
    return nums2.toList()
}
fun main(){
    var numbers = listOf<Int>(1,2,3,4,5,6,7,8,9)
    val evens = numbers.filter { it%2==0 }
    evens.forEach {print("$it ") }
    println()
    val doubles = evens.map{it * 2}
    doubles.forEach{print("$it ")}
    println()
    //or do it at once

    var results = numbers.filter { it%2==0 }.map{it * 2}
    results.forEach{print("$it ")}
    println()

    val t = numbers.take(2)
    t.forEach{print("$it ")}
    println()
    println(t.joinToString(", "))

    val nums = listOf(1,2,3,4,4,5,6,6,7,8,9,9)
    val result = get_result(nums)
    println(result)

}