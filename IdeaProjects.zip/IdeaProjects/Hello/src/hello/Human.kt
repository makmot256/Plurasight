package hello

open class Human {
    val x = 5

    open fun walk(){
        println("Humans walk")
    }
}