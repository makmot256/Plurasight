package hello

data class Person5 (var age:Int, var name:String)
