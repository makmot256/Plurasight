package hello;

public class First {

    public static void main(String[] args){
        MainKt.myFunction();//calling a kotlin method in a java class
        System.out.println(MainKt.myFunction4());
    }
}
