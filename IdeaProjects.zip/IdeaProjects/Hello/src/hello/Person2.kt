package hello

class Person2 (var age:Int, var name:String){
// or class Person2 constructor(var age:Int, var name:String){

    fun display(age:Int){
        println(age)
        println(this.name)
    }
}

fun main() {
    val person = Person2(21,"Arnold")

    println(person.name)
    println("My name is ${person.name}")
    person.display(person.age)
    }
