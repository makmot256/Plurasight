package hello

import java.math.BigInteger

//for small numbers
// for  big numbers it gives zero as the output
fun factorial(n:Int):Int{
    if(n==1){
        return 1
    }
    else{
        return n * factorial(n -1)
    }
}
//for big numbers
fun factorial2(n:BigInteger): BigInteger {
    if(n== BigInteger.ONE){ //BigInteger.ONE is the same as BigInteger("1")
        return BigInteger("1")
    }
    else{
        return n * factorial2(n - BigInteger("1"))
    }
}
//Tail recursion overcomes the issue of stack overflow
tailrec fun factorial3(n:BigInteger, result:BigInteger): BigInteger {
    if(n == BigInteger.ONE){ //BigInteger.ONE is the same as BigInteger("1")
        return result
    }
    else{
        return factorial3(n - BigInteger("1"),n * result)
    }
}
fun main(){
    println(factorial(15))
    println(factorial2(BigInteger("75")))
    println(factorial3(BigInteger("75"), BigInteger.ONE))

}