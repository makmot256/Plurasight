package hello

fun main(){
    println("Enter number")
    val num  = readlnOrNull()
    println(num)
    println("Enter name")
    val name  = readLine()
    println(name)

}
