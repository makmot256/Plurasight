package hello
//age and name are not accessible because they are not fields or properties of the class until the primary constructor is called.
class Person3 (var age:Int, var name:String){
    var iDNo : Int? = null
// or class Person3 constructor(var age:Int, var name:String){

    //Secondary constructor
    //The this(age, name) delegates to the primary constructor and initializes age and name before setting iDNo.
    constructor(iDNo:Int, age:Int, name :String) : this(age, name) {
        this.iDNo = iDNo

    }
   
    fun display(age:Int){
        println(age)
        println(this.name)
    }
}

fun main() {
    val person = Person3(21, "Arnold")

    println(person.name)
    println("My name is ${person.name}")
    person.display(person.age)
    val person2 = Person3(154, 26, "Peter")
    println(person2.iDNo)

}
