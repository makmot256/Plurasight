package hello

class Person : Human(){
    var age = 0
    var name = ""



    fun display(){
        println(this.x)
    }
    infix fun otherName(lastName:String){
        println("${this.name} $lastName")

    }
    operator fun plus(age:Int){
        println("${this.name} : $age")
    }

    operator fun plus(other:String):String{
        return "${this.name} $other"
    }
    //overriding
    override fun walk(){
        println("A person can walk")
    }
}
fun main() {
    val person = Person()
    person.name = "Arnold"
    person.age = 21

    println(person.name)
    println(person.age)
    person.display()
    person otherName "Kisomose"// infix allows us to do this(no need for the dot syntax)
    person.otherName("Patrick")
    person + 23 //operator overloading
    person.plus(23)

    val person2 = Person()
    person2.name = "Pat"

    val result = person2 + person.name //operator overloading
    println(result)
    val result2 = person2.plus(person.name)
    println(result)

    val p = Person()
    p.walk()

    val p1 : Human = Person() //  for java Human h = new Person()
    p1.walk()

    }
