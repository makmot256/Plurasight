package inheritance

open class Animal(age : Int) {
    var age :Int = 0
    init{
        println("Animals $age")
    }

}