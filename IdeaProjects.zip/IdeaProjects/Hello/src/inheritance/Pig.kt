package inheritance

class Pig :Animal2() {
    override fun makeSound(){
        println("wee wee")
    }

}