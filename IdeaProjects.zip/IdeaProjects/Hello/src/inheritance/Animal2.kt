package inheritance

abstract class Animal2() {

    abstract fun makeSound()

}