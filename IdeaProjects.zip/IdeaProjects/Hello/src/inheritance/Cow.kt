package inheritance

class Cow(age : Int) : Animal(age) {
    init {
        println("Cows")
    }
}

    fun main(){
        val c = Cow(20)
    }
