package interfaces

class Dog  : Animal5{
    override fun makeSound(){
        println("barks")
    }
}
fun main(){
    val d = Dog()
    d.makeSound()
    d.color()
}