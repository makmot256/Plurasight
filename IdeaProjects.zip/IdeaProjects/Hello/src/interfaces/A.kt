package interfaces

interface A {
    fun a()
    fun show(){
        println("Show in A")
    }
}
interface B {
    fun b()
    fun show(){
        println("Show in B")
    }
}
class C :A,B{
    override fun a(){
        println("A")
    }
    override fun b(){
        println("B")
    }
    override fun show(){
        super<A>.show()
    }
}
fun main(){
    val c = C()
    c.show()
}