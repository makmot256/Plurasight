package interfaces

interface Animal5 {
    fun makeSound()
    fun color(){
        println("black")
    }
}