package objects

fun main(){
     var a : A = object : A {// or var a  = object : A
         override fun show() {
             println("Show A")
         }
     }
    a.show()
    var b  = object : B() {
        override fun display(){
            println("show in main")
        }
    }
    b.display()
}