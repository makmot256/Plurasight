package objects

class CompanionObject {
    companion object{
        var name = "Arnold"
        @JvmStatic
        fun p(){
            println("Hello")
        }
        fun create(): CompanionObject{
            return CompanionObject()
        }
    }
    fun myfun(){
        println("Factory Pattern")
    }
}
fun main(){
    CompanionObject.p()
    val c = CompanionObject()
    c.myfun()
     val c2 = CompanionObject.create() // object is created in the factory method
    c2.myfun()
}