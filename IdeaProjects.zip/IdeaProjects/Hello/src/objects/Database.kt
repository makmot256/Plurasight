package objects

object Database {
    val name = "Oracle"
    fun connect(){
        println("Connected to $name")
    }
}fun main(){
    Database.connect()
    println(Database.name)
}