package objects

open class B {
    open fun display(){
        println("Show B")
    }
}