package objects;

public class CompanionMain {

    public static void main(String[] args){
        CompanionObject.p();
    }
}
