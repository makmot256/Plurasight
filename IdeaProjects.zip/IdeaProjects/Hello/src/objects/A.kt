package objects

interface A {
    fun show()
}