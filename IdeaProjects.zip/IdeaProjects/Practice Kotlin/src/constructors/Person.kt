package constructors

class Person(var name : String, var age : Int)