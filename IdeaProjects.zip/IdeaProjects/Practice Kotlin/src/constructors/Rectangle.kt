package constructors

class Rectangle(val width : Int, val height : Int) {

    constructor(width : Int) : this(width, 1)
}