package constructors

class Car(var make: String, var model: String,var year:Int){

    constructor(make: String, model: String):this(make,model,2024)
}


fun main(){
    val c = Car("Toyota", "Japan",)
    println(c.year)
    println(c.make)
}