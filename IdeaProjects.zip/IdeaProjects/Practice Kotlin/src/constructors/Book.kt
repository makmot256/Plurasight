package constructors

class Book(private var title: String, private var author: String,  private var year: Int?=null) {

}

