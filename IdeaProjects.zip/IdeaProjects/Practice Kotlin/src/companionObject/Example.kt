package companionObject

class Example {
    val lazyValue: String by lazy {
        println("Computed!")
        "Hello world"
    }
}
fun main(){
    val example = Example()
    // The first access triggers the computation
    println(example.lazyValue)
    // Subsequent access does not trigger the computation again
    println(example.lazyValue)
}