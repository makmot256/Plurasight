package companionObject

class User(val name : String) {
    companion object{
        fun createUser(name:String):User{
            return User(name)
        }
    }
}
fun main(){
    val user1 = User.createUser("Arnold")
    println(user1.name)
}