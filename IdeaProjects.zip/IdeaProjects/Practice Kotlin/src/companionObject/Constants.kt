package companionObject

class Constants {
    companion object{
        const val API_URL = "https://"
        const val TIMEOUT = 9
    }
}
fun main(){
    println("API URL: ${Constants.API_URL}")
    println("Timeout: ${Constants.TIMEOUT} seconds")
}