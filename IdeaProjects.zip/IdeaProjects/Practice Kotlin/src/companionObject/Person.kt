package companionObject

//How would you use a companion object to track the number of instances of a class Person?

class Person(var name:String,val age:Int) {
    companion object{
        private var instanceCount = 0

        fun getInstanceCount():Int{
            return instanceCount
        }
    }
    init{
        instanceCount++
    }
}
fun main(){
    val person1 = Person("Alice",11)
    val person2 = Person("Bob",54)
    val person3 = Person("Kinda",23)
    val person4 = Person("Peter",12)
    println("Number of Person instances: ${Person.getInstanceCount()}")
}