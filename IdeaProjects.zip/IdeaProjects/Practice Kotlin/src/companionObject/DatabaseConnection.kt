package companionObject

class DatabaseConnection private constructor() {
    companion object{
        val instance: DatabaseConnection by lazy {DatabaseConnection()}
    }
}
fun main(){
    val dbConnection = DatabaseConnection.instance
    val dbConnection2 = DatabaseConnection.instance
    println(dbConnection == dbConnection2)
    /*The expression dbConnection1 === dbConnection2 checks if
    both references point to the same instance.
    Since the Singleton pattern ensures that only one instance exists,
    this will return true.
     */
}