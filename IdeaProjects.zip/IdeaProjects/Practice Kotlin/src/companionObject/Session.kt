package companionObject

class Session private constructor() {
    // Enum to represent session states
    enum class SessionStatus {
        ACTIVE,
        INACTIVE
    }

    // Variable to hold the current session status
    private var status: SessionStatus = SessionStatus.INACTIVE

    companion object {
        // Singleton instance of Session
        private val instance: Session = Session()

        // Method to start a session
        fun startSession() {
            instance.status = SessionStatus.ACTIVE
            println("Session started.")
        }

        // Method to end a session
        fun endSession() {
            instance.status = SessionStatus.INACTIVE
            println("Session ended.")
        }

        // Method to get the current session status
        fun getSessionStatus(): SessionStatus {
            return instance.status
        }
    }
}

fun main() {
    // Using the Session companion object methods
    Session.startSession()
    println("Current session status: ${Session.getSessionStatus()}") // Output: ACTIVE

    Session.endSession()
    println("Current session status: ${Session.getSessionStatus()}") // Output: INACTIVE
}