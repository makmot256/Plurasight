package companionObject

class Logger private constructor(){
    companion object{
        // Method to log informational messages
        fun logInfo(message: String) {
            println("INFO: $message")
        }

        // Method to log warning messages
        fun logWarning(message: String) {
            println("WARNING: $message")
        }

        // Method to log error messages
        fun logError(message: String) {
            println("ERROR: $message")
        }

    }
}
fun main(){
    Logger.logInfo("This is an informational message.")
    Logger.logWarning("This is a warning message.")
    Logger.logError("This is an error message.")
}