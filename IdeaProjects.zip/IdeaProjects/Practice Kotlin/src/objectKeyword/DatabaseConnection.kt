package objectKeyword

//constructors are not allowed for objects
object DatabaseConnection {
    var name : String ="Oracle"
    fun connect(){
        println("Connected to ${this.name}")
    }
}
fun main(){
    DatabaseConnection.connect()
    println("Please enter the first number:")
    val num1 = readLine()?.toDoubleOrNull() ?: return println("Invalid input for the first number.")

    println("Please enter the second number:")
    val num2 = readLine()?.toDoubleOrNull() ?: return println("Invalid input for the second number.")

    println("Select an operation:")
    println("1: Addition")
    println("2: Subtraction")
    println("3: Multiplication")
    println("4: Division")

    val input = readLine()

    val result = when (input?.toIntOrNull()) {
        1 -> num1 + num2 // Addition
        2 -> num1 - num2 // Subtraction
        3 -> num1 * num2 // Multiplication
        4 -> if (num2 != 0.0) num1 / num2 else "Cannot divide by zero" // Division with check
        else -> "Invalid input"
    }
}
