package objectKeyword

import functionExpressions.addition

class MathUtils {
    companion object{
        fun addition(x:Int,y:Int):Int{
            return x + y
        }
        fun multiplication(x:Int,y:Int):Int{
            return x * y
        }
    }
}
fun main(){
    println(MathUtils.addition(6,4))
    println(MathUtils.multiplication(6,4))
}