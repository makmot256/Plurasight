package userInput

fun main(){
//    /*Write a simple Kotlin program that reads a user's name from the console and prints a greeting
//    message.*/
//    println("Enter name")
//    val name = readLine()
//    println("Hello, $name")
//    println()
//    /*Create a menu-driven program that accepts user input to perform different actions based on
//            the user's choice.*/
//
//    println("Enter two numbers")
//    val num1 = readLine()?.toIntOrNull() ?: return println("Invalid input for the first number.")
//    val num2 = readLine()?.toIntOrNull() ?: return println("Invalid input for the second number.")
//    println("Which operation do you want to peform:")
//    println("1. Addition")
//    println("2. Subtraction")
//    println("3. Multiplication")
//    println("4. Division")
//    val input = readLine()
//    val result = when(input?.toIntOrNull()){
//        1 -> num1 + num2
//        2 -> num1 - num2
//        3 -> num1 * num2
//        4 -> num1 / num2
//        else -> "Invalid input"
//    }
//    println("Result : $result")
//
   /* Write a Kotlin program that reads a list of numbers from the user, sorts them, and prints the
    sorted list*/
    val numbers = mutableListOf<Double>()
    println("Enter numbers")

    while(true){
        val input = readLine()
        if(input.equals("done",ignoreCase = true)){
            break
        }
        val number = input?.toDoubleOrNull()
        if(number != null){
            numbers.add(number)
        }
        else{
            println("Invalid input. Please enter a valid number or type 'done' to finish.")
        }
    }
    numbers.sort()
    numbers.forEach {print("$it\t")}
    println()
    println("Sorted numbers: ${numbers.joinToString(", ")}")


}