package functionExpressions

fun addition(x :Int,y:Int) : Int = x + y

fun checkEven(x :Int): Boolean =  (x%2==0)
val check : (Int) -> Boolean = {x -> x%2==0}// lambda expression
fun greet(name :String):String = "Hello, $name!"

fun main() {
    println(checkEven(4))
    println(checkEven(5))
    println(check(5))
}