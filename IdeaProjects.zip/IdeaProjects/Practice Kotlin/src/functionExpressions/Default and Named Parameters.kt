package functionExpressions

fun details(name : String,age:Int = 18){
    println(name)
    println(age)
}

fun sum(x : Int, y :Int=0, z :Int=0):Int{
    return x + y + z
}
fun area(width : Int=0, height : Int=0):Int{
    return width * height
}

fun main(){
    println(sum(x=7,z=8))
    println(area(height = 5,width=12))

}