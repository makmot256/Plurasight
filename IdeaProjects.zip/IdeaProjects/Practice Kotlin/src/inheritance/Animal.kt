package inheritance

open class Animal(var name : String) {
    open fun makeSound(){
        println("every animal makes a sound")
    }
}