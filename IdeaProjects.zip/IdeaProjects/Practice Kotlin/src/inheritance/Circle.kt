package inheritance

import kotlin.math.PI

class Circle(private val radius : Double) : Shape() {
    override fun area() :Double{
        return PI * this.radius * this.radius

    }
}
fun main(){
    val c = Circle(2.0)
    println(c.area())
}