package inheritance

open class Person(var name : String) {
}