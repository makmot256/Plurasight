package inheritance

class Dog(name: String) : Animal(name) {

    override fun makeSound(){
        println("A dog barks")
    }
}