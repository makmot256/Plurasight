package inheritance

open class Shape {
    open fun area():Double{
        return 0.0
    }
}