package inheritance

class Employee(name : String, var employeeId : String) : Person(name){
}