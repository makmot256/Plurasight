package anonymousInnerClass

open class Outer {
    open fun display(){
        println("Inside outer")
    }
}
fun main(){
    val inner = object : Outer(){
        override fun display(){
            println("Inside inner")
        }
    }
    inner.display()

    val strings = listOf( "longer","short", "lengthiest")
    //val sortedStrings = strings.sortedWith { o1, o2 -> o1.length - o2.length } lambda
    val sortedStrings = strings.sortedWith(object : Comparator<String> {
        override fun compare(o1: String, o2: String): Int {
            return o1.length - o2.length
        }
    })
    println(sortedStrings)

}