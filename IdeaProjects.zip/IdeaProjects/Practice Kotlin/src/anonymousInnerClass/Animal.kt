package anonymousInnerClass

abstract class Animal {
    abstract fun makeSound()
}

fun main(){
    val dog = object : Animal(){
        override fun makeSound() {
            println("woof woof")
        }
    }
    dog.makeSound()
}
