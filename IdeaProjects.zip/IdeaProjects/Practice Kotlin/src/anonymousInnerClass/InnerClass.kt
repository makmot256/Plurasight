package anonymousInnerClass

fun main(){
    //val runnable = Runnable{println("Running in an anonymous inner class!")}
    val runnable = object: Runnable{
        override fun run(){
            println("Running in an anonymous inner class!")
        }
    }
    Thread(runnable).start()
}