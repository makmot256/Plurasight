package anonymousInnerClass

interface Calculator {
    fun calculate(x:Int,y:Int):Int
}
fun main(){
    val cal = object : Calculator{
        override fun calculate(x: Int, y: Int): Int {
            return x + y
        }
    }
    println(cal.calculate(9,9))
}