package anonymousInnerClass

data class Person(val name: String, val age: Int)

fun main(){
    val person = listOf<Person>(Person("Peter",30),Person("Okello",43),
        Person("Alice",12))
//val ageComparator = Comparator<Person> { p1, p2 -> p1.age.compareTo(p2.age) } lambda expression
    val ageComparator = object : Comparator<Person>{
        override fun compare(p1:Person,p2:Person):Int{
            return p1.age.compareTo(p2.age)
        }
    }
    val sortedPeople = person.sortedWith(ageComparator)

    sortedPeople.forEach { println(it) }
}