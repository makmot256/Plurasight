package tryexpression

import java.io.File
import java.io.FileNotFoundException
import java.io.IOException

fun main(){
    val filePath = "D:\\files.txt"
        val file = File(filePath)
        val content = try {
             "ppp ${file.readText()}"
           // println("File content:\n$content")
        }
        catch(e: IOException){
            "An error occurred while reading the file: ${e.message}"

        }
    catch(e: FileNotFoundException){
        "File not found: ${e.message}"
    }
    println(content)



}