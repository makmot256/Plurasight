package tryexpression

fun main(){
    val input = readLine()
    val number = try{
        input?.toInt()
    }
    catch(e : NumberFormatException) {
        println("Not an integer")
    }
    println("Entered number: $number")
}