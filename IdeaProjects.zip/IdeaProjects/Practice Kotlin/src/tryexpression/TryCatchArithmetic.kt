package tryexpression

fun main(){
//    val a = 2
//    val b = 0
//    var c =0
//    try{
//        if(b==0){
//            throw ArithmeticException("Division by zero is not possible")
//        }
//    }
//    catch (e : ArithmeticException){
//        println(e.localizedMessage)
//    }
//    c = a + b
//    println(c)
    //try expression

    val numerator = 20
    val denominator = 0
    val result = try{
        numerator/denominator
    }
    catch(e : ArithmeticException){
        "Division by zero is not allowed"
    }
    println(result)

}