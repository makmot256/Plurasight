package extensionfunction

import java.text.SimpleDateFormat
import java.util.*
import kotlin.NoSuchElementException

fun Int.isEven():Boolean{
    return (this%2==0)
}
fun <T> List<T>.second():T?{
    return if(this.size >= 2) this[1] else null
}
//or
fun <T> List<T>.second2(): T {
    if (this.size < 2) {
        throw NoSuchElementException("List has fewer than two elements.")
    }
    return this[1]
}
fun List<Int>.sumBy(factor : Int): Int{
    return this.sumOf{it * factor}
}
fun String.toDate(): Date?{
    return try {
        val format = SimpleDateFormat("yyyy-mm-dd", Locale.getDefault())
        format.parse(this)
    }
    catch(e:Exception){
        null
    }

}
fun main(){
    val number = 7
    println(number.isEven())

    val numbers = listOf(1,3,6,4,5)
    println(numbers.second2())
    println(numbers.second())
    println(numbers.sumBy(10))

    val dateString = "2023-11-20"
    val date = dateString.toDate()
    println(date)
}