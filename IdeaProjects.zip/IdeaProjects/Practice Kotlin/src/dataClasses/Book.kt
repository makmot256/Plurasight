package dataClasses

data class Book(var name : String, var price : Int)

data class Library(var name : String, var books:List<Book>)

fun main(){
    val b = listOf<Book>(Book("Kotlin",50000),Book("OOP",20000))
    val lib = Library("Cocis",b)

    println(lib)
}