package dataClasses

data class Person(var name : String, var age : Int)

fun main(){
    val person = Person("Arnold",21)
    val person2 = person.copy(name="Peter",age=14)
}