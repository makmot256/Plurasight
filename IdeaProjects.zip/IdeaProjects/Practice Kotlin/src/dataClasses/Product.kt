package dataClasses
data class Product(var name : String, var price : Int,var quantity : Int) {
    fun  total(){
        println("${this.name} = " + this.price * this.quantity)
        //println("${this.name} = ${this.price} * ${this.quantity}")
    }
}
fun main(){
    val p = Product("Sugar", 5000,2)
    p.total()
}

