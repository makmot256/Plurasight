package loops_and_Ranges

fun main() {
    //Write a program using a for loop to print numbers from 1 to 10
    for (x in 1..10) {
        print("$x ")
    }
    println()

    //Use a range to print all even numbers from 1 to 20.
    var nums = 1..20
    for (x in nums) {
        if (x % 2 == 0) {
            print("$x ")
        }
    }
    println()
    //Write a nested loop in Kotlin that prints a multiplication table from 1 to 10.
    for (i in 1..10) {
        for (j in 1..10) {
            val product = i * j
            print("$product\t")
        }
        println()
    }

    //Write a Kotlin program that uses a while loop to read user input until the word "exit" is entered.
    println("Enter Student Name")
    while (readlnOrNull() != "exit") {
        println("Enter another Student Name (type 'exit' to quit)")
    }
    println("Exiting the program.")

}
