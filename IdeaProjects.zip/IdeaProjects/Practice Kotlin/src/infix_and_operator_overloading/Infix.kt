package infix_and_operator_overloading

infix fun Int.add(other:Int):Int{
    return this + other
}
fun main(){
    val num1 = 4
    val num2 = 5
    val result = num1 add num2
    val result1 = num1.add(num2)
    println("The sum of $num1 and $num2 is $result")
    println("The sum of $num1 and $num2 is $result1")
}

