package infix_and_operator_overloading

data class Fraction(var numerator : Int,var denominator : Int) {

    init{
        require(denominator != 0){"Denominator cannot be zero"}
    }

     operator  fun plus(other : Fraction) : Fraction{
         val newNumerator = (this.numerator * other.denominator) + (other.numerator * this.denominator)
         val newDenominator = this.denominator * other.denominator
        return Fraction(newNumerator,newDenominator)
    }
    override fun toString(): String {
        return "$numerator/$denominator"
    }
}
fun main(){
    val fraction1 = Fraction(1,2)
    val fraction2 = Fraction(1,3)
    val result = fraction1 + fraction2
    println("$fraction1 + $fraction2 = $result")
}

//data class Fraction(val numerator: Int, val denominator: Int) {
//
//    init {
//        require(denominator != 0) { "Denominator cannot be zero." }
//    }
//
//    // Overloading the + operator
//    operator fun plus(other: Fraction): Fraction {
//        val newNumerator = this.numerator * other.denominator + other.numerator * this.denominator
//        val newDenominator = this.denominator * other.denominator
//        return Fraction(newNumerator, newDenominator).simplify()
//    }
//
//    // Function to simplify the fraction
//    private fun simplify(): Fraction {
//        val gcd = gcd(numerator, denominator)
//        return Fraction(numerator / gcd, denominator / gcd)
//    }
//
//    // Function to calculate the greatest common divisor (GCD)
//    private fun gcd(a: Int, b: Int): Int {
//        return if (b == 0) a else gcd(b, a % b)
//    }
//
//    // Override toString for better output
//    override fun toString(): String {
//        return "$numerator/$denominator"
//    }
//}
//
//fun main() {
//    // Create two Fraction instances
//    val fraction1 = Fraction(1, 0) // 1/2
//    val fraction2 = Fraction(1, 3) // 1/3
//
//    // Add the two fractions using the overloaded + operator
//    val result = fraction1 + fraction2
//
//    // Print the result
//    println("$fraction1 + $fraction2 = $result")
//}