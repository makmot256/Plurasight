package infix_and_operator_overloading

class Point(var x : Int,var y : Int) {

    infix fun move(delta:Point){
        this.x += delta.x
        this.y += delta.y
    }
}

fun main(){
    val p1 = Point(3,7)
    val p2 = Point(4,6)
    p1 move(p2)
    println("x = ${p1.x} y = ${p1.y}")
}