package infix_and_operator_overloading

data class ComplexNumber(var real : Double, var imaginary: Double) {

    operator fun plus(other:ComplexNumber):ComplexNumber{
        return ComplexNumber(this.real + other.real,this.imaginary + other.imaginary)

    }

    override fun toString(): String {
        return "$real + ${imaginary}i"
    }

}
fun main(){
    val c1 = ComplexNumber(2.0,7.0)
    val c2 = ComplexNumber(2.0,1.0)
    val result = c1 + c2
    println("$c1 + $c2 = $result")
}