package abstract_Classes_and_Interfaces

class Rectangle : Shape() {
        override fun area(){
            println("Area = Length * Width")
        }
}