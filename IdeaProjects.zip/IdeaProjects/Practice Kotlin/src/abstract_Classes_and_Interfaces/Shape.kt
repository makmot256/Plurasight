package abstract_Classes_and_Interfaces

abstract class Shape {
    abstract fun area()
}