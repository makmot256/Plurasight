package abstract_Classes_and_Interfaces

class Circle : Shape(), Drawable {
    override fun area(){
        println("Area = PI * radius * radius")
    }
    override fun draw(){
        println("Draw a circle")
    }
}