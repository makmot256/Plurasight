package higherOrderFunctions

fun operate(x:Int,y:Int, operation: (Int, Int) -> Int): Int {
    return operation(x,y)
}
fun add(x:Int,y:Int):Int{
    return x + y
}
fun subtract(x:Int,y:Int):Int{
    return x - y
}
val square: (Int)->Int = {x->x*x}//lambda expression
fun applyFunction(num:Int,func:(Int)->Int):Int{
    return func(num)
}
fun square(x:Int):Int = x*x
fun main(){
    println(operate(10,9,::add))
    println(operate(10,9,::subtract))
    println(applyFunction(4,::square))
    println(applyFunction(4,square))
}