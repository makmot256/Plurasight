package arrays

fun main(){
    //Create an array of integers, modify its third element, and print all elements using a loop.
    var nums = arrayOf(1,2,3,4,5,6)
    nums.set(2,9)
    for(p in nums){
        print("$p ")
    }
    println()
    //Write a Kotlin program that reverses an array of integers.
    for(x in nums.reversedArray()){
        print("$x ")
    }
    println()
    println(nums.get(5))
    /*Create and initialize a two-dimensional array. Write a program to perform matrix addition on
    two 2x2 matrices.*/

    var matrix1: Array<IntArray> = arrayOf(intArrayOf(1,2),intArrayOf(3,4))
    var matrix2 = arrayOf(intArrayOf(5,7),intArrayOf(8,9))
    val resultMatrix = Array(2){IntArray(2)}

    for(i in 0..1){
        for(j in 0..1){
            resultMatrix[i][j] = matrix1[i][j] + matrix2[i][j]
        }
    }
    println("Result of Matrix Addition:")
    for(row in resultMatrix){
        println(row.joinToString(" "))
    }

    val mat = Array(3){IntArray(3)}
    for(i in 0..2){
        for(j in 0..2){
            mat[i][j] = i + j

        }
    }

    println(mat.contentDeepToString())

    val n: Array<Int>? = arrayOf()
    val my_element = n?.firstOrNull()
    println(my_element)



}